use chrono::NaiveDate;

struct User {
    id: u16,
    first_name: String,
    last_name: String,
    midle_name: String,
    email: String,
    phone: String,
    date_of_birth: NaiveDate,
    date_employment: NaiveDate,
    position: String,
    id_department: u16,
}

struct Credentials {
    id_user: u16,
    login: String,
    password: String,
    public_key: String,
    private_key: String,
}

struct Job {
    id_user: u16,
    id_project: [u16],
    id_role: u16,
    id_task: [u16],
}

struct Department {
    id: u16,
    id_active_module: [u8],
    id_head: u16,
    employees: [u16],
    id_project: [u16],
}

struct Phonebook {
    id: u8,
    user_id: u16,
    status: String,
    schedule: NaiveDate,
}

struct Role {
    id: u8,
    name: String,
    id_active_module: [u8],
    id_permissions: [u8],
}

struct Module {
    id: u8,
    name: String,
    // something else? too hard to guess, need each module implementation to go further, i suppose
}

struct Project {
    id: u16,
    id_head: u16,
    title: String,
    description: String,
    avatar: String,
    date_started: NaiveDate,
    date_ended: NaiveDate,
    members: [u16],
    supervisors: Option<[u16]>,
    tasks: [u16],
}

struct Task {
    id: u16,
    id_project: u16,
    id_head: u16,
    supervisors: Option<[u16]>,
    responsible: String,
    description: String,
    date_started: NaiveDate,
    date_ended: NaiveDate,
    current_status: String,
    priority: String,
    sub_tasks: Option<[u16]>,
}
