mod internal;
use std::{error::Error as StdError, fmt::format};
use internal::database::database::{DataBase, InsertBuilder};


#[tokio::main]
async fn main() -> Result<(), Box<dyn StdError>> {
    let mut client = DataBase::get_connection().await?;
    DataBase::create_tables(&mut client).await;
    
    internal::transport::server::start().await;
    Ok(())
}

