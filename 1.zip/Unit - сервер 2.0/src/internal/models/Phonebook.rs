use chrono::NaiveDate;

pub struct Phonebook {
    id:         u8,
    user_id:    u16,
    status:     String,
    schedule:   NaiveDate,
}