pub struct Credentials {
    id_user:        u16,
    login:          String,
    password:       String,
    public_key:     String,
    private_key:    String,
}