pub struct Job {
    id_user:        u16,
    id_project:     Vec<u16>,
    id_role:        u16,
    id_task:        Vec<u16>,
}