pub struct Role {
    id:                 u8,
    name:               String,
    id_active_module:   Vec<u8>,
    id_permissions:     Vec<u8>,
}