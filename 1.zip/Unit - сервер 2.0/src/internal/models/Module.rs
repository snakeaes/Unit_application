pub struct Module {
    id:     u8,
    name:   String
}