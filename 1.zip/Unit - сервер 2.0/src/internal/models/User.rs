use chrono::NaiveDate;

pub struct User {
    id:                 u16,
    first_name:         String,
    last_name:          String,
    midle_name:         String,
    email:              String,
    phone:              String,
    date_of_birth:      NaiveDate,
    date_employment:    NaiveDate,
    position:           String,
    id_department:      u16,
}