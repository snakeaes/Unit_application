use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct Person {
    name: String,
    role: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Signed {
    day: String,
    month: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Vacation {
    days: String,
    since: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Approved {
    status: bool,
    role: String,
    name: String,
    day: String,
    month: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Data {
    to: Person,
    from: Person,
    vacation: Vacation,
    signed: Signed,
    approved: Approved,
    year: String,
}