use chrono::NaiveDate;

pub struct Project {
    id:             u16,
    id_head:        u16,
    title:          String,
    description:    String,
    avatar:         String,
    date_started:   NaiveDate,
    date_ended:     NaiveDate,
    members:        Vec<u16>,
    supervisors:    Option<Vec<u16>>,
    tasks:          Vec<u16>,
}