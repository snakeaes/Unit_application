use chrono::NaiveDate;

pub struct Task {
    id:                u16,
    id_project:        u16,
    id_head:           u16,
    supervisors:       Option<Vec<u16>>,
    responsible:       String,
    description:       String,
    date_started:      NaiveDate,
    date_ended:        NaiveDate,
    current_status:    String,
    priority:          String,
    sub_tasks:         Option<Vec<u16>>,
}