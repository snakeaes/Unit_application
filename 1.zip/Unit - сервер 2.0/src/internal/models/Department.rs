pub struct Departments {
    id:                 u16,
    id_active_module:   Vec<u8>,
    id_head:            u16,
    employees:          Vec<u16>,
    id_project:         Vec<u16>,
}