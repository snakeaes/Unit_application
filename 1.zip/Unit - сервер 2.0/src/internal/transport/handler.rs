use std::collections::HashMap;

use axum::{extract::Query, Json};
use serde_json::json;
use crate::internal::database::database::{DataBase, InsertBuilder, SelectBuilder, UpdateBuilder};
use crate::internal::models::Docs::{Data};

use std::io::{Write};
use std::process::Command;
use axum::body::Body;
use axum::http::{Response, StatusCode};

pub struct Handler {}


impl Handler {
    // pub async fn get_user(query: Query<std::collections::HashMap<String, String>>) -> Json<serde_json::Value> {
    //     let phone_number = query.get("phone_number").unwrap();
    //     let where_str: String = format!("phone_number = '{}'", phone_number);
    
    //     let mut client = DataBase::get_connection().await.unwrap();
    //     let mut select_query = SelectBuilder::new("application");
    //     select_query.select_columns("*")
    //         .where_condition(&where_str);
    
    //     let result_rows = select_query.execute(&mut client).await.unwrap();
    
    //     let mut user: Option<Application> = None;
    
    //     for row in result_rows {
    //         let id: i32 = row.get(0);
    //         let full_name: String = row.get(1);
    //         let phone_number: String = row.get(2);
    //         let type_equipment: String = row.get(3);
    //         let problem: String = row.get(4);
    //         let date_application: String = row.get(5);
    //         let status: String = row.get(6);
    
    //         user = Some(Application {
    //             id,
    //             full_name,
    //             phone_number,
    //             type_equipment,
    //             problem,
    //             date_application,
    //             status,
    //         });
    //     }
    
    //     if let Some(user) = user {
    //         let json_value = serde_json::to_value(&user).unwrap();
    //         return Json(json_value);
    //     }
    
    //     Json(serde_json::Value::Null)
    // }


    pub async fn add_user(query: Json<HashMap<String, String>>) -> Json<serde_json::Value> {
        let data = &query;

        let mut client = DataBase::get_connection().await.unwrap();
        let mut insert_query = InsertBuilder::new("application");
        for (key, value) in data.iter() {
            println!("key - {}, value - {}", &key, &value);
            insert_query.add_column_value(&key, &value);
        }
        insert_query.execute(&mut client).await.unwrap();

        let response_data = json!({
            "message": "User added successfully"
        });

        Json(response_data)
    }

    
    pub async fn upd_user(query: Json<HashMap<String, String>>) -> Json<serde_json::Value> {
        let data = &query.0;
    
        println!("{:?}", data);
    
        if let Some(id) = data.get("id") {
            let id_str = id.as_str();
    
            let mut client = DataBase::get_connection().await.unwrap();
            let mut update_query = UpdateBuilder::new("application"); 
            for (key, value) in data.iter() {
                if key != "id" {
                    update_query.set_value(&key, &value);
                }
            }
            update_query.where_condition(&format!("id = {}", id_str)); 
            update_query.execute(&mut client).await.unwrap();
    
            let response_data = json!({
                "message": "User updated successfully"
            });
    
            return Json(response_data);
        } else {
            let response_data = json!({
                "error": "User ID is missing in the request"
            });
    
            return Json(response_data);
        }
    }


    pub async fn get_admin(query: Query<HashMap<String, String>>) -> Json<serde_json::Value> {
        let data = query;

        let user_input_login = data.get("login").unwrap();
        let user_input_password = data.get("password").unwrap();

        let mut client = DataBase::get_connection().await.unwrap();
        let mut select_query = SelectBuilder::new("admin");
            select_query.select_columns("*");
        
        let result_rows = select_query.execute(&mut client).await.unwrap();

        for row in result_rows {
            let login: String = row.get(1);
            let password: String = row.get(2);

            if user_input_login == &login && user_input_password == &password {
                let response_data = json!({
                    "message": "User authorization successfully"
                });
                return Json(response_data)
            }
        }
    
        let error_response = json!({
            "error": "Invalid login or password data"
        });
    
        Json(error_response)
    }


    // pub async fn get_all_application() -> Json<serde_json::Value> {
    //     let mut client = DataBase::get_connection().await.unwrap();
    //     let mut select_query = SelectBuilder::new("application");
    //         select_query.select_columns("*");

    //     let result_rows = select_query.execute(&mut client).await.unwrap();
        
    //     let mut applications = Vec::new();
        
    //     for row in result_rows {
    //         let id: i32                     = row.get(0);
    //         let full_name: String           = row.get(1);
    //         let phone_number: String        = row.get(2);
    //         let type_equipment: String      = row.get(3);
    //         let problem: String             = row.get(4);
    //         let date_application: String    = row.get(5);
    //         let status: String              = row.get(6);
        
    //         let application = Application {
    //             id,
    //             full_name,
    //             phone_number,
    //             type_equipment,
    //             problem,
    //             date_application,
    //             status,
    //         };
            
    //         applications.push(serde_json::to_value(&application).unwrap());
    //     }
        
    //     Json(serde_json::Value::Array(applications))
    // }


    pub async fn add_check(query: Json<HashMap<String, String>>) -> Json<serde_json::Value> {

        let data = &query;

        let mut client = DataBase::get_connection().await.unwrap();
        let mut insert_query = InsertBuilder::new("checks");
        for (key, value) in data.iter() {
            println!("key - {}, value - {}", &key, &value);
            insert_query.add_column_value(&key, &value);
        }
        insert_query.execute(&mut client).await.unwrap();

        let response_data = json!({
            "message": "User added successfully"
        });

        Json(response_data)
    }

    pub async fn doc(Json(data): Json<Data>) -> Response<Body> {
        let text = serde_json::to_string(&data).unwrap();
        let mut file = std::fs::File::create("vacation.json").unwrap();
        file.write_all(text.as_bytes()).unwrap();
        Command::new("typst")
            .arg("compile")
            .arg("vacation.typ")
            .output()
            .unwrap();
        let content = std::fs::read("vacation.pdf").unwrap();
        Response::builder()
            .status(StatusCode::OK)
            .header("Content-Type", "application/pdf")
            .header("Content-Disposition", "attachment; filename=request.pdf")
            .body(Body::from(content))
            .unwrap()
    }


    // pub async fn get_check() -> Json<serde_json::Value> {

    //     let mut client = DataBase::get_connection().await.unwrap();
    //     let mut select_query = SelectBuilder::new("checks");
    //         select_query.select_columns("*");

    //     let result_rows = select_query.execute(&mut client).await.unwrap();
        
    //     let mut checks = Vec::new();
        
    //     for row in result_rows {
    //         let id: i32                     = row.get(0);
    //         let full_name: String           = row.get(1);
    //         let phone_number: String        = row.get(2);
    //         let type_equipment: String      = row.get(3);
    //         let date_check: String          = row.get(4);
    //         let price: String               = row.get(5);
        
    //         let application = Check {
    //             id,
    //             full_name,
    //             phone_number,
    //             type_equipment,
    //             date_check,
    //             price,
    //         };
            
    //         checks.push(serde_json::to_value(&application).unwrap());
    //     }
        
    //     Json(serde_json::Value::Array(checks))        
    // }
}