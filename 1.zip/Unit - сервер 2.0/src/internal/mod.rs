pub mod transport 
{
    pub mod server;
    pub mod handler;
}

pub mod database
{
    pub mod database;
}

pub mod models
{
   pub mod User;
   pub mod Role;
   pub mod Task;
   pub mod Project;
   pub mod Department;
   pub mod Module;
   pub mod Phonebook;
   pub mod Credentials;
   pub mod Job;
   pub mod Docs;
}