use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct Check
{
    pub id: i32,
    pub full_name: String,
    pub phone_number: String,
    pub type_equipment: String,
    pub date_check: String,
    pub price: String,
}