use crate::internal::transport::handler::Handler;
use axum::{
    response::IntoResponse, routing::{get, post}, Json, Router
};
use http::HeaderName;
use tower_http::cors::{Any, CorsLayer};
use axum::http::Method;

pub async fn start() {

    let cors: CorsLayer = CorsLayer::new()
    .allow_methods(vec![Method::POST, Method::PUT, Method::DELETE])
    .allow_origin(Any)
    .allow_headers(vec![
        HeaderName::from_bytes(b"Content-Type").unwrap(),
    ]);

    let app = Router::new()
        .route("/get_user", get(Handler::get_user))
        .route("/add_user", post(Handler::add_user))
        .route("/upd_user", post(Handler::upd_user))
        .route("/get_admin", get(Handler::get_admin))
        .route("/get_application", get(Handler::get_all_application))
        .route("/get_check", get(Handler::get_check))
        .route("/add_check", post(Handler::add_check)).layer(cors);

        let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
        axum::serve(listener, app).await.unwrap();
}